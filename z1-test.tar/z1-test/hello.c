#include <stdbool.h>
#include <stdint.h>
#include <stdnoreturn.h>

#include "alienos.h"

#define LINES 24
#define COLS 80

static __attribute__((section(".params"))) int repeats;

asm (
	".global _start\n"
	"_start:\n"
	"call main\n"
	"hlt\n"
);

static noreturn void end(int status) {
	register int arg asm("edi");
	arg = status;
	asm volatile (
		"syscall\n"
		:
		: "a"(0), "r"(arg)
	);
	__builtin_unreachable();
}

static void print(int x, int y, uint16_t *data, int n) {
	register int res asm("eax");
	register int arg0 asm("edi");
	register int arg1 asm("esi");
	register void *arg2 asm("rdx");
	register int arg3 asm("r10");
	arg0 = x;
	arg1 = y;
	arg2 = data;
	arg3 = n;
	asm volatile (
		"syscall\n"
		: "=r"(res)
		: "a"(3), "r"(arg0), "r"(arg1), "r"(arg2), "r"(arg3)
		: "rcx", "r11", "memory"
	);
}

static void setcursor(int x, int y) {
	register int res asm("eax");
	register int arg0 asm("edi");
	register int arg1 asm("esi");
	arg0 = x;
	arg1 = y;
	asm volatile (
		"syscall\n"
		: "=r"(res)
		: "a"(4), "r"(arg0), "r"(arg1)
		: "rcx", "r11"
	);
}

static int getkey() {
	register int res asm("eax");
	asm volatile (
		"syscall\n"
		: "=r"(res)
		: "a"(2)
		: "rcx", "r11"
	);
	return res;
}

static uint32_t getrand() {
	register uint32_t res asm("eax");
	asm volatile (
		"syscall\n"
		: "=r"(res)
		: "a"(1)
		: "rcx", "r11"
	);
	return res;
}

noreturn void main() {
	char string[] = "Hello, world!";
	static const int len = sizeof string - 1;
	uint16_t buf[len];
	if (repeats > LINES)
		end(2);
	for (int i = 0; i < len; i++)
		buf[i] = string[i] | 0xa00;
	for (int line = 0; line < repeats; line++) {
		print((COLS - len) / 2, line + (LINES - repeats) / 2, buf, len);
	}
	setcursor(COLS - 1, LINES - 1);
	getkey();
	end(0);
}
